#ifndef MWETK_MAIN
#define MWETK_MAIN

#include <stdio.h>
#include "base.h"
#include "readline.h"
#include "suffixarray.h"

int main(int argc, char **argv);

#endif
